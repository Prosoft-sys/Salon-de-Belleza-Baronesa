<?php

require '../BD/conectar.php';

$sql = "SELECT * FROM servicio";

$ejecutar = mysqli_query($db, $sql) or die (mysqli_error($db));



$sqli = "SELECT * FROM cliente";

$eje = mysqli_query($db, $sqli) or die (mysqli_error($db));



$sq = "SELECT * FROM empleado";

$exe = mysqli_query($db, $sq) or die (mysqli_error($db));




?>
