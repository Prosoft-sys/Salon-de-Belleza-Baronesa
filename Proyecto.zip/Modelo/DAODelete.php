<?php

include_once("../Controlador/crud.php");
 
$crud = new Crud();
 

$id = $crud->escape_string($_GET['id']);
 

$result = $crud->delete($id,'turno');
 
if ($result) {
    
    header ("Location: ../Vista/inicio.php");

 
}
?>