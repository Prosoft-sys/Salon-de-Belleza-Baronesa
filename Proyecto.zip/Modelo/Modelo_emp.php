<?php

include_once ("../Controlador/Cruds.php");
include_once ("../Controlador/Validation.php");
 
$crud = new Crud();
$validation = new Validation();
 
if(isset($_POST['update']))
{    
    $Id = $crud->escape_string($_POST['Id']);

    $Nombre = $crud->escape_string($_POST['Nombre']);
    $Apellido = $crud->escape_string($_POST['Apellido']);
    $FechaInicio = $crud->escape_string($_POST['FechaInicio']);
    $FechaFinal = $crud->escape_string($_POST['FechaFinal']);
    $Estado = $crud->escape_string($_POST['Estado']);
    $Usuario = $crud->escape_string($_POST['Usuario']);
    
    
    
    

    
    
        $result = $crud->execute("UPDATE empleado SET Nombre='$Nombre', Apellido='$Apellido', FechaInicio='$FechaInicio', FechaFinal='$FechaFinal', Estado='$Estado', Usuario='$Usuario' WHERE Id=$Id");
        
     
        header ("Location: ../Modelo/index.php");
    
}
?>
