<?php

require ('../BD/conectar.php');

$usuario = $_POST['usuario'];
$clave = $_POST['clave'];



$sql = "SELECT Usuario, Clave FROM empleado WHERE Usuario = '$usuario'";
$result = mysqli_query($db, $sql);
$row = mysqli_fetch_array($result);

$count = mysqli_num_rows($result);



if($count > 0)
{
    
    $USU = $row['Usuario'];
    $CLA = $row['Clave'];

    session_start(); 
    if(password_verify($clave, $CLA))
    {       
        
            
           if( $_SESSION['Nombre_sesion'] = $USU)
           {
            
            header ("Location: ../Vista/Inicio.php"); 
           }
           else
           {
               echo "Ingrese usuario y contraseña";
           }    
           
       
    }
    else
    {
       
        header ("Location: ../Vista/respuesta2.php");    
        
    }  
}
else
{
    
    header ("Location: ../Vista/respuesta.php"); 
    
    
}

?>