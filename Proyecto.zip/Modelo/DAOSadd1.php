<?php

  require ('../BD/conectar.php');

$Documento = $_POST['documento'];
$Nombre = $_POST['nombre'];
$Apellido = $_POST['apellido'];
$FechaRegistro = $_POST['fechacliente'];
$Genero = $_POST['genero'];
$Usuario = $_POST['usuario'];
$Email = $_POST['correo'];
$Clave = $_POST['clave'];
$CON = md5 ($Clave);

    
    $sqli1 = "INSERT INTO cliente (DocumentoCliente, NombreCliente, ApellidoCliente, FechaRegistroCliente, Genero, Usuario, Correo, ClaveCliente)  
    VALUES ('$Documento','$Nombre','$Apellido','$FechaRegistro','$Genero','$Usuario','$Email','$CON')";
    $results = mysqli_query($db, $sqli1);


    if($counts = 1)
    {
        header ("Location: ../Vista/respuesta5.1.php");
       
        
       

    }
    else
    {
        echo "falla al registar";
        
    }

    
   

?>
</body>
</html>