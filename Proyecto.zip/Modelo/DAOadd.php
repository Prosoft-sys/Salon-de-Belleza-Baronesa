<?php
 
 require_once '../BD/conectar.php';


 $ServicioId = $_POST['Servicio'];
$ClienteId = $_POST['Cliente'];
$EmpleadoId = $_POST['Empleado'];
$FechaReserva = $_POST['Fecha'];
$HoraReserva = $_POST['Hora'];





    
    $sqli = "INSERT INTO turno (ServicioId, ClienteId, EmpleadoId, FechaReserva, HoraReserva) VALUES ('$ServicioId','$ClienteId','$EmpleadoId','$FechaReserva','$HoraReserva')";
    $results = mysqli_query($db, $sqli);
    $row = mysqli_fetch_array($results);

    $counts = mysqli_num_rows($results);

    if($counts = 1)
    {
        header ("Location: ../Vista/respuesta3.php");     

    }
    else
    {
        echo "falla al registar";
        
    }    
   

?>