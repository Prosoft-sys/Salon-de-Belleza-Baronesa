<?php
 
 require_once '../BD/conectar.php';

        $Documento = $_POST['Documento'];
        $nombrec = $_POST['nombre'];
        $apellidoc = $_POST['apellido'];
        $fechare = $_POST['fechacliente'];
        $genero = $_POST['genero'];
        $usuario = $_POST['usuario'];
        $correo = $_POST['correo'];
        $clavecliente = $_POST['clave'];





    
    $sqli = "INSERT INTO cliente (DocumentoCliente, NombreCliente, ApellidoCliente, FechaRegistroCliente, Genero, Usuario, Correo, ClaveCliente) VALUES ($Documento, '$nombrec','$apellidoc','$fechare','$genero','$usuario','$correo','$clavecliente')";
    $results = mysqli_query($db, $sqli);
    $row = mysqli_fetch_array($results);

    $counts = mysqli_num_rows($results);

    if($counts = 1)
    {
        header ("Location: ../Vista/respuesta4.php"); 
  

    }
    else
    {
        echo "falla al registar";
        
    }    
   

?>