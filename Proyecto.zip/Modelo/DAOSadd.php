<?php

  require ('../BD/conectar.php');

$Documento = $_POST['documento'];
$Nombre = $_POST['nombre'];
$Apellido = $_POST['apellido'];
$FechaInicio = $_POST['fechai'];
$FechaFinal = $_POST['fechaf'];
$Estado = 'ACTIVO';
$Usuario = $_POST['usuario'];
$Email = $_POST['correo'];
$Clave = $_POST['clave'];
$CON = md5 ($Clave);

    
    $sqli = "INSERT INTO empleado (DocumentoEmpleado, NombreEmpleado, ApellidoEmpleado, FechacontratoInicio, FechacontratoFinal, Estado, Correo, Usuario, Clave) VALUES ('$Documento','$Nombre','$Apellido','$FechaInicio','$FechaFinal','$Estado','$Email','$Usuario','$CON')";
    $results = mysqli_query($db, $sqli);
    $row = mysqli_fetch_array($results);

    $counts = mysqli_num_rows($results);

    if($counts = 1)
    {
        header ("Location: ../Vista/respuesta5.php");
        
       

    }
    else
    {
        echo "falla al registar";
        
    }

    
   

?>
</body>
</html>