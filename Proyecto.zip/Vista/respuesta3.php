<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<html>
<head>    
<link rel="shoortcut icon"href="../PDF/logo4.png">
    <title>Reservas</title>
</head>
<br>
<center>
<body bgcolor="black" style="background-color:#B2BABB">


<img src="../PDF/logo4.png" width="450" height="">

<h1><font color="black" face="Arial" size="5">SE HA REGISTRADO SU RESERVACIÓN CORRECTAMENTE</font></h1>
<br>


<a href="../Vista/reporteturno.php" class="btn btn-warning" style = "background-color:#1C2833"><i class="fa fa-angle-left"></i>Generar resivo de su turno</a><br><br>

<a href="../Vista/Portada.php" class="btn btn-warning" style = "background-color:#1C2833"><i class="fa fa-angle-left"></i>Volver</a>
</body>
</center>
</html>