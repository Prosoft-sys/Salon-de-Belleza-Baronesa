<html>
<link rel="shoortcut icon"href="../PDF/logo4.png">
<title>Registrar Empleado </title>

<div class="form-group" style="background-image:url(../PDF/fondo1.jpg)">
<center>
<img src="../PDF/logo4.png" width="450" height="">
<h1><font color="white" face="Arial" size="5">REGISTRAR CLIENTE</font></h1><br>
</center>
</div>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>



<form class="form-horizontal" action="../Modelo/DAOSadd1.php" method="post"  style="background-color:#B2BABB">
<fieldset>

<!-- Form Name -->
<legend></legend>

<div class="form-group">
  <label class="col-md-4 control-label" >Documento</label>  
  <div class="col-md-5">
  <input name="documento" type="text"  class="form-control input-md">
    
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label" >Nombre</label>  
  <div class="col-md-5">
  <input name="nombre" type="text"  class="form-control input-md">
    
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label" >Apellido</label>  
  <div class="col-md-5">
  <input name="apellido" type="text"  class="form-control input-md">
    
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label" >Fecha Registro de Cliente</label>  
  <div class="col-md-5">
  <input name="fechacliente" type="date"  class="form-control input-md">
    
  </div>

</div>

<div class="form-group">
  <label class="col-md-4 control-label" >Genero</label>  
  <div class="col-md-5">
  <input name="genero" type="text"  class="form-control input-md">
    
  </div>
</div>



<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" >Usuario</label>  
  <div class="col-md-5">
  <input name="usuario" type="text"  class="form-control input-md">
    
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label" >Correo</label>  
  <div class="col-md-5">
  <input name="correo" type="email"  class="form-control input-md">
    
  </div>
</div>


<div class="form-group">
  <label class="col-md-4 control-label" >Clave Cliente</label>  
  <div class="col-md-5">
  <input name="clave" type="password"  class="form-control input-md">
    
  </div>
</div>



<!-- Button -->
<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="enviar"></label>
  <div class="col-md-4">
    <button  name="enviar" class="btn btn-success" style = "background-color:#1C2833">Registrar</button>  <a href="../Index1.php" class="btn btn-warning" style = "background-color:#1C2833"><i class="fa fa-angle-left"></i>Volver</a><br><br>
  </div>
</div>

</fieldset>
</form>

</html>