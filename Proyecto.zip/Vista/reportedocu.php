<html>
<link rel="shoortcut icon"href="../PDF/logo4.png">
<title>Registrar Reservar </title>

<div class="form-group" style="background-image:url(../PDF/fondo1.jpg)">
<center>
<img src="../PDF/logo4.png" width="450" height="">
<h1><font color="white" face="Arial" size="5">GENERAR REPORTE DE CLIENTE POR PRESTACION DE UN SERVICIO</font></h1><br>



</center>
</div>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>



<form class="form-horizontal" action="../PDF/reporte.php" method="post" style="background-color:#B2BABB">
<fieldset>

<!-- Form Name -->
<legend></legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" >ID Cliente</label>  
  <div class="col-md-5">
  <input name="docume" type="text"  class="form-control input-md" >
    
  </div>
</div>



<!-- Button -->
<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="enviar"></label>
  <div class="col-md-4">
    <button  name="enviar" class="btn btn-success" style = "background-color:#1C2833">Generar</button>  <a href="../Vista/Inicio.php" class="btn btn-warning" style = "background-color:#1C2833"><i class="fa fa-angle-left"></i>Volver a inicio</a><br><br><br><br>
  </div>
</div>

</fieldset>
</form>

</html>