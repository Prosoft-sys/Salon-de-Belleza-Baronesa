<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<html>
<link rel="shoortcut icon"href="../PDF/logo4.png">
<title>Iniciar sesion</title>
  <head>

  <link href="../Vista/ini.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
  </head>
<body id="LoginForm">
<div class="container">
<h1 class="form-heading"></h1>
<div class="login-form">
<div class="main-div">
    <div class="panel">
    <img src="../PDF/logo4.png" width="250" height=""><br/><br>
   <h2>Iniciar Sesion</h2>
   
   </div>
    <form action ="" method = "post">


        <div class="forgot">
        Debe ingresar un usuario y una contraseña valida
</div>
       
        <a href="../index1.php" type="submit" class="btn btn-primary">Volver</a>

    </form>
    </div>

</div></div></div>


</body>
</html>
