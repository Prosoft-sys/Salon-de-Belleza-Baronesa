<?php 

    require_once '../BD/conectar.php';
  

        session_start();
        $usuario = $_SESSION ['username'];
        if(!isset($usuario)){
                header("location: index1.php");
        }else{

        }


?>


<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<head>
    <meta charset="UTF-8">
    <link rel="shoortcut icon"href="../PDF/logo4.png">
    <title>Que Corte!</title>
    
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Built with Blueprints app">
      <meta name="author" content="Bootstraptor.com">
      <link rel="icon" href="favicon.ico">
 
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css">
      <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    

      <!-- Plugins -->
    </head>
<body>
<ul class="nav justify-content-end" style = "background-color:#1C2833;" >

<li class="nav nav-pills">
  <a class="nav-link active" href="../Controlador/cerrarsesion1.php">Cerrar Sesion</a>
</li>

</ul>

      <section class="pt-5 pb-5 bg-dark position-relative" style="min-height:100vh; background-image: url(../PDF/fondo3.jpg); background-size: cover;">
        <div class="bg-overlay"></div>
        <div class="container pt-5 pb-5 position-relative">
          <div class="row d-flex justify-content-between pt-lg-5 align-items-center">
            <div class="col-xl-5 col-lg-6 col-md-7 text-center text-lg-left mb-5 mb-lg-0">
                <img src="../PDF/logo4.png" width="450" height="">

              <h3 class="display-3 font-weight-bold text-white aos-init aos-animate" data-aos="fade-up">Registrate para poder ser parte de nosotros </h3>
              <div class="my-4 aos-init" data-aos="fade-up">
                <p class="lead text-white">Servicios de peluqueria y belleza para hombre, mujer y niñ@s</p>
              </div>
            
            </div>
            <div class="col">
              <div class="row justify-content-center">
                <div class="col-xl-8 col-md-10">
                  <form class="position-relative d-block aos-init aos-animate" data-aos="fade-up">
                    
                   
                  
                    <div class="form-group text-center">

                      <a href="../Vista/Vista.php" class="btn btn-lg btn-success btn-block mb-2" type="submit" style = "background-color:#1C2833">Reservar</a>
                      <a href="../Vista/SALON.php" class="btn btn-lg btn-success btn-block mb-2" type="submit" style = "background-color:#1C2833">Volver al menu de opciones de cuenta</a>

                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>

      </section>
      

      
  
  
   


      <!-- jQuery is required -->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.2/js/bootstrap.min.js"></script>
      <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
       AOS.init({
          duration: 1200,
        })
  </script>
    

</body>