/* 
<?php 

    require_once '../BD/conectar.php';
  

        session_start();
        $usuario = $_SESSION ['username'];
        if(!isset($usuario)){
                header("location: index.php");
        }else{

        }


?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!-- CSS only -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<link rel="styleshet" href="ini.css">
<!-- JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

<?php

include_once ("../Controlador/crud.php");
 
$crud = new Crud();
 
$query = "SELECT * FROM turno inner join servicio on turno.ServicioId = servicio.IdServicio inner join empleado on turno.EmpleadoId = empleado.IdEmpleado inner join cliente on turno.ClienteId = cliente.IdCliente ORDER BY IdTurno DESC";

$result = $crud->getData($query);

?>

<html>
<head> 
<link rel="shoortcut icon"href="../PDF/logo4.png">   
    <title>Reservas</title>
</head>


<ul class="nav justify-content-end" style = "background-color:#1C2833;" >

  <li class="nav nav-pills">
    <a class="nav-link active" href="../Controlador/cerrarsesion.php">Cerrar Sesion</a>
  </li>

</ul>
<br>
<br>
<br>
<br>
<br>




<center>
<body bgcolor="black" style="background-color:#B2BABB">


<img src="../PDF/logo4.png" width="450" height="">

<h1><font color="black" face="Arial" size="5">RESERVAS REGISTRADAS</font></h1>
<br>

<a href="../Vista/Reportesalario.php"  class="btn btn-warning" style = "background-color:#1C2833; color: white"><i style ="color:white" class="fa fa-angle-left" style = "background-color:#1C2833"></i>Generar reporte de salario diario</a>  <a href="../Vista/reportedocu.php" class="btn btn-warning" style = "background-color:#1C2833; color: white"><i class="fa fa-angle-left" style = "background-color:#1C2833; color: white"></i>Generar reporte de cliente por servicio</a>   <a href="../Vista/Reporte.php" class="btn btn-warning" style = "background-color:#1C2833; color: white"><i class="fa fa-angle-left"></i>Reporte de cliente por dia</a> <a href="../Vista/ReporteEmpleado.php" class="btn btn-warning" style = "background-color:#1C2833; color: white"><i class="fa fa-angle-left"></i>Cantidad de Turnos Empleado</a>  <br> <br>


 
    </table>
    
</body>

</center>
</html>