<html>
<link rel="shoortcut icon"href="../PDF/logo4.png">
<title>Registrar Reservar </title>

<div class="form-group" style="background-image:url(../PDF/fondo1.jpg)">
<center>
<img src="../PDF/logo4.png" width="450" height="">
<h1><font color="white" face="Arial" size="5">RESERVAR</font></h1><br>



</center>
</div>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>



<form class="form-horizontal" action="../Modelo/DAOadd.php" method="post" style="background-color:#B2BABB">
<fieldset>

<!-- Form Name -->
<legend></legend>

<div class="form-group">
  <label class="col-md-4 control-label" >Servicio</label>
  <div class="col-md-5">
    <select name="Servicio" class="form-control">
    <?php
    require '../Modelo/DAOSelectservicio.php';  
    ?>
      <option value="1">Seleccione:</option>   

      <?php foreach($ejecutar as $opcion): ?>

      <option value="<?php echo $opcion['IdServicio'] ?>"><?php echo $opcion['NombreServicio']?> <?php echo $opcion['PrecioServicio']?></option>

      <?php endforeach ?>
    </select>
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label" >Cliente</label>
  <div class="col-md-5">
    <select  name="Cliente" class="form-control">
      <option value="1">Seleccione:</option>
      <?php
        require '../Modelo/DAOSelectservicio.php'; 
    ?>
      

      <?php foreach($eje as $opcion): ?>

      <option value="<?php echo $opcion['IdCliente'] ?>"><?php echo $opcion['NombreCliente']?> <?php echo $opcion['ApellidoCliente']?></option>

      <?php endforeach ?>
     
    </select>
  </div>
</div>

<div class="form-group">
  <label class="col-md-4 control-label" >Empleado</label>
  <div class="col-md-5">
    <select name="Empleado" class="form-control">
      <option value="1">Seleccione:</option>
      <?php
     require '../Modelo/DAOSelectservicio.php'; 

    ?>
      

      <?php foreach($exe as $opcion): ?>

      <option value="<?php echo $opcion['IdEmpleado'] ?>"><?php echo $opcion['NombreEmpleado']?> <?php echo $opcion['ApellidoEmpleado']?></option>

      <?php endforeach ?>
     
    </select>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" >Fecha de reserva</label>  
  <div class="col-md-5">
  <input name="Fecha" type="date"  class="form-control input-md">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" >Hora de reserva</label>  
  <div class="col-md-5">
  <input name="Hora" type="time"  class="form-control input-md" >
    
  </div>
</div>

<!-- Button -->
<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="enviar"></label>
  <div class="col-md-4">
    <button  name="enviar" class="btn btn-success" style = "background-color:#1C2833">Reservar</button>  <a href="../Vista/Portada.php" class="btn btn-warning" style = "background-color:#1C2833"><i class="fa fa-angle-left" style = "background-color:#1C2833"></i>Volver</a><br><br>
  </div>
</div>

</fieldset>
</form>

</html>