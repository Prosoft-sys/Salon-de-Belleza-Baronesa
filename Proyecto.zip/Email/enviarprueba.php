<?php

require ('Phpmailer/Exception.php');
require ('Phpmailer/PHPMailer.php');
require ('Phpmailer/SMTP.php');
require ('../BD/conectar.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


$correo = $_POST['correo'];

$con = "SELECT * FROM empleado WHERE Correo = '$correo'";
$results = mysqli_query($db, $con);
$row = mysqli_fetch_array($results);

$nom = $row['NombreEmpleado'];
$ape = $row['ApellidoEmpleado'];

if($row)
{


$template = file_get_contents('../Vista/PLANTILLACORREO.php');
$template = str_replace("{{name}}", $nom, $template);
$template = str_replace("{{name2}}", $ape, $template);
$template = str_replace("{{year}}", date('yy'), $template);
$template = str_replace("{{action_url_2}}",'<b>http://localhost:8080/APLICATIVO/Vista/CambiarClave.php</b>', $template);
$template = str_replace("{{action_url_1}}",'http://localhost:8080/APLICATIVO/Vista/CambiarClave.php', $template);



// Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);
$mail->CharSet = "UTF-8";

try {
    //Server settings
    $mail->SMTPDebug = 0;                      // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'salondebellezabaresa2020@gmail.com';                     // SMTP username
    $mail->Password   = 'BARESA2020';                               // SMTP password
    $mail->SMTPSecure = 'tls';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('salondebellezabaresa2020@gmail.com', 'Administracion Baronesa');
    $mail->addAddress($correo);    // Add a recipient
        
    $mail->addReplyTo('info@example.com', 'Information');
    $mail->addCC('cc@example.com');
    $mail->addBCC('bcc@example.com');


    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Solicitud de renovación de contraseña';
    $mail->Body    = $template;
   

    $mail->send();
    header ("Location: ../Vista/RES3.php");
}
 catch (Exception $e) 
{
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
}
else
{
    header ("Location: ../Vista/RES2.php");
}



?>