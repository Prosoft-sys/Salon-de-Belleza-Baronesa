<?php

define('DB_SERVER', 'localhost');
    define('DB_USERNAME', 'oskdictm_ProyectoUsuario');
    define('DB_PASSWORD', 'Andres2001');
    define('DB_DATABASE', 'oskdictm_Proyecto');
    $db = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

    ?>
    
