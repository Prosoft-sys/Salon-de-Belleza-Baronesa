<?php

require 'conectar.php';


session_start();

$usuario = $_POST['usuario'];
$clave = $_POST ['clave'];
$clave1 = md5($clave);


$q = "SELECT COUNT(*) AS contar from empleado where Usuario = '$usuario' and Clave  = '$clave1'";


$results = mysqli_query($db, $q);
$array = mysqli_fetch_array($results);




if ($array['contar']>0){
  $_SESSION ['username'] = $usuario;
  header("location: ../Vista/Inicio.php");

  

}else {
  header ("location: ../Vista/respuesta.php");

}


?>