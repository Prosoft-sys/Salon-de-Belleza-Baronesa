<?php
class DbConfig 
{    
    private $_host = 'localhost';
  private $_username = 'oskdictm_ProyectoUsuario';
    private $_password = 'Andres2001';
    private $_database = 'oskdictm_Proyecto';
    
    protected $connection;
    
    public function __construct()
    {
        if (!isset($this->connection)) {
            
            $this->connection = mysqli_connect($this->_host, $this->_username, $this->_password, $this->_database);
            
            if (!$this->connection) {
                echo 'Error en la conexion';
                exit;
            }            
        }    
        
        return $this->connection;
    }
}
?>