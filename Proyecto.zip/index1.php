<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<html>
<link rel="shoortcut icon"href="../PDF/logo4.png">
  <title>Iniciar sesion</title>
  <head><meta charset="euc-jp">
         <?php

            if(isset($errorLogin)){
                echo $errorLogin;
            }

       ?>
  <link href="Vista/ini.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
  </head>
    <body id="LoginForm">
    <div class="container">
    <h1 class="form-heading"></h1>
    <div class="login-form">
    <div class="main-div">
      <div class="panel">
      <img src="PDF/logo4.png" width="250" height=""><br><br>
       <h2>Iniciar Sesion Cliente</h2>
   
   </div>
    <form action ="BD/LogearCliente.php" method = "post">

        <div class="form-group">


            <input type="text" class="form-control" name="usuario" placeholder="Usuario">

        </div>

        <div class="form-group">

            <input type="password" class="form-control" name="clave" placeholder="Contrasena">

        </div>
        <div class="forgot">
        ¿No tiene cuenta de Cliente?<br> Registrate <a href="Vista/add1.php">Registrar</a><br><br>

        ¿No recuerdas tu clave?<br> Registrate <a href="Vista/Recuperar.php">Recuperar clave</a>
</div>
        <button type="submit" class="btn btn-primary">Iniciar</button><br><br>
        <a href="Vista/SALON.php" type="submit" class="btn btn-primary">Volver al menu de opciones de cuenta</a>

    </form>
    </div>

</div></div></div>


</body>
</html>
