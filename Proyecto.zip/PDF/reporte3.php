<?php



require ('../PDF/fpdf/fpdf.php');


class PDF extends FPDF
{
    function Header()
    {
        // Logo
    $this->Image('../PDF/logo.png',80,10,100);   
    $this->Ln(90);
    // Arial bold 15
    $this->SetFont('Arial','B',12);
    // Movernos a la derecha
    $this->Cell(80);
    // Título
    $this->Cell(90,10,'Reporte de pago',1,0,'C');
    // Salto de línea
    $this->Ln(20);
    $this->SetY(120);
    $this->SetX(10);
    $this->Cell(50,10,'NO.', 0, 0,'C',0);
    $this->Ln(20);


    $this->SetY(140);
    $this->SetX(10);
    $this->Cell(50,10,'Nombre', 1, 0,'C',0);

    $this->SetY(140);
    $this->SetX(60);
    $this->Cell(50,10,'Apellido', 1, 0,'C',0);

    $this->SetY(140);
    $this->SetX(110);
    $this->Cell(50,10,'Salario (dia)', 1, 0,'C',0);

    $this->SetY(140);
    $this->SetX(160);
    $this->Cell(50,10,'Ganancia del salon', 1, 0,'C',0);
    
    $this->SetY(140);
    $this->SetX(210);
    $this->Cell(50,10,'Ganancia por servicio', 1, 0,'C',0);

    $this->Ln(20);
    

    }

    function Footer()
    {
         // Posición: a 1,5 cm del final
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Número de página
    $this->Cell(20,10,'Pagina '.$this->PageNo().'/{nb}',0,0,'C');
    }
}

require ('../BD/conectar.php');

require ('../PDF/consultareporte7.php');
$resultpaga = mysqli_query($db, $paga);


$pdf = new PDF('L','mm','Letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

require ('../PDF/consultareporte8.php');
$resultpagasalon = mysqli_query($db, $pagasalon);


$pdf = new PDF('L','mm','Letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

require ('../PDF/consultareporte9.php');
$resultotal = mysqli_query($db, $pagatotal);


$pdf = new PDF('L','mm','Letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

require ('../PDF/consultareporte10.php');
$resultfech = mysqli_query($db, $fech);


$pdf = new PDF('L','mm','Letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

require ('../PDF/consultareporte11.php');
$resultid = mysqli_query($db, $id);


$pdf = new PDF('L','mm','Letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);



while($rpw = $resultpaga->fetch_assoc())
{ 
    $pdf->SetY(150);
    $pdf->SetX(10);  
    $pdf->Cell(50,10,$rpw['NombreEmpleado'], 0, 0,'C',0); 
    $pdf->Cell(50,10,$rpw['ApellidoEmpleado'], 0, 0,'C',0);
    $pdf->Cell(50,10,$rpw['Salario'],0, 0,'C',0); 
    
    
    
}
while($rps = $resultpagasalon->fetch_assoc())
{
    $pdf->Cell(50,10,$rps['SalarioSalon'],0,0,'C',0);
}

while($to = $resultotal->fetch_assoc())
{
    $pdf->Cell(50,10,$to['Total'],0,0,'C',0);

}
while($fe = $resultfech->fetch_assoc())
{
    $pdf->SetY(120);
    $pdf->SetX(200);
    $pdf->Cell(50,10,$fe['FechaReserva'],0,0,'C',0);
}

while($d = $resultid->fetch_assoc())
{
    $pdf->SetY(120);
    $pdf->SetX(20);
    $pdf->Cell(50,10,$d['IdEmpleado'],0,0,'C',0);
}


$pdf->Output();

?>