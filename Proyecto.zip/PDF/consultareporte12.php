<?php


$c = $_POST['documentocliente'];

$y = $_POST['hoy'];

$sql= "SELECT * FROM turno inner join servicio on turno.ServicioId = servicio.IdServicio inner join empleado on turno.EmpleadoId = empleado.IdEmpleado inner join cliente on turno.ClienteId = cliente.IdCliente WHERE FechaReserva = '$y' AND IdCliente = $c "
?>