
<?php

$em = $_POST['empleadodocu'];
$fe = $_POST['fechahoyp'];

$paga = "SELECT (sum(PrecioServicio)*0.4) as Salario, NombreEmpleado, FechaReserva, ApellidoEmpleado FROM turno INNER JOIN servicio on servicio.IdServicio = turno.ServicioId INNER JOIN empleado on empleado.IdEmpleado = turno.EmpleadoId where IdEmpleado = $em and FechaReserva = '$fe'";

?>