<?php


$q = $_POST['documentocliente'];

$er = $_POST['hoy'];

$s= "SELECT * FROM turno inner join servicio on turno.ServicioId = servicio.IdServicio inner join empleado on turno.EmpleadoId = empleado.IdEmpleado inner join cliente on turno.ClienteId = cliente.IdCliente WHERE FechaReserva = '$er' AND IdCliente = $q "
?>