
<?php

$em = $_POST['empleadodocu'];
$fe = $_POST['fechahoyp'];

$fech = "SELECT * FROM turno INNER JOIN servicio on servicio.IdServicio = turno.ServicioId INNER JOIN empleado on empleado.IdEmpleado = turno.EmpleadoId where IdEmpleado = $em and FechaReserva = '$fe'";

?>