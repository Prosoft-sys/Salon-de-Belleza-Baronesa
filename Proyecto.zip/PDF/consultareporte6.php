<?php


$n = $_POST['docume'];

$t = "SELECT * FROM turno WHERE ClienteId = $n";




?>