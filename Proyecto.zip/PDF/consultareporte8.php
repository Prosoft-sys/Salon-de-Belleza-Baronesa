
<?php

$em = $_POST['empleadodocu'];
$fe = $_POST['fechahoyp'];

$pagasalon = "SELECT (sum(PrecioServicio)*0.6) as SalarioSalon, NombreEmpleado, FechaReserva FROM turno INNER JOIN servicio on servicio.IdServicio = turno.ServicioId INNER JOIN empleado on empleado.IdEmpleado = turno.EmpleadoId where IdEmpleado = $em and FechaReserva = '$fe'";

?>