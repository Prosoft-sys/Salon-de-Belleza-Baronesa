<?php


$a = $_POST['docume'];

$l = "SELECT * FROM cliente WHERE IdCliente = $a";




?>