<?php



require ('../PDF/fpdf/fpdf.php');


class PDF extends FPDF
{
    function Header()
    {
        // Logo
    $this->Image('../PDF/logo.png',80,10,100);   
    $this->Ln(90);
    // Arial bold 15
    $this->SetFont('Arial','B',12);
    // Movernos a la derecha
    $this->Cell(80);
    // Título
    $this->Cell(90,10,'Reporte de cliente',1,0,'C');
    // Salto de línea
    $this->Ln(20);

    $this->Cell(50,10,'Cliente', 0, 0,'C',0);

    $this->Ln(20);


    $this->SetY(140);
    $this->SetX(10);
    $this->Cell(20,10,'Turno', 1, 0,'C',0);

    $this->SetY(140);
    $this->SetX(30);
    $this->Cell(50,10,'Servicio', 1, 0,'C',0); 
    

    $this->SetY(140);
    $this->SetX(80);
    $this->Cell(50,10,'Empleado', 1, 0,'C',0);

    $this->SetY(140);
    $this->SetX(130);
    $this->Cell(50,10,'Precio', 1, 0,'C',0);

    $this->SetY(140);
    $this->SetX(180);
    $this->Cell(50,10,'Fecha', 1, 0,'C',0);
   


    $this->Cell(40,10,'Hora', 1, 1,'C',0);

    

    }

    function Footer()
    {
         // Posición: a 1,5 cm del final
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Número de página
    $this->Cell(20,10,'Pagina '.$this->PageNo().'/{nb}',0,0,'C');
    }
}

require ('../BD/conectar.php');

require ('../PDF/consultareporte.php');
$resultado = mysqli_query($db, $consulta);


$pdf = new PDF('L','mm','Letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

require ('../PDF/consultareporte5.php');
$res = mysqli_query($db, $l);


$pdf = new PDF('L','mm','Letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);


require ('../PDF/consultareporte6.php');
$rest = mysqli_query($db, $t);


$pdf = new PDF('L','mm','Letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

while($row = $resultado->fetch_assoc())
{  
  
    
    $pdf->Cell(20,10,$row['IdTurno'], 1, 0,'C',0);    
    
    $pdf->Cell(50,10,$row['NombreServicio'], 1, 0,'C',0); 
    
    $pdf->Cell(50,10,$row['NombreEmpleado'], 1, 0,'C',0); 

    $pdf->Cell(50,10,$row['PrecioServicio'], 1, 0,'C',0);
    
    $pdf->Cell(50,10,$row['FechaReserva'], 1, 0,'C',0);
    
    $pdf->Cell(40,10,$row['HoraReserva'], 1, 1,'C',0);

    
    
    
}

while($ron = $res->fetch_assoc())
{
    $pdf->SetY(120);
    $pdf->SetX(50);
    $pdf->Cell(20,10,$ron['NombreCliente'], 0, 0,'C',0);
}




$pdf->Output();

?>

