<?php


$h = $_POST['fechahoy'];

$sql="SELECT FechaReserva, EmpleadoId FROM turno "


?>