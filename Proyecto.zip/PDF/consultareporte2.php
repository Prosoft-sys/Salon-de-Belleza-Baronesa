<?php


$h = $_POST['documentoempleado'];

$j = $_POST['fechahoy'];

$sql= "SELECT * FROM turno inner join servicio on turno.ServicioId = servicio.IdServicio inner join empleado on turno.EmpleadoId = empleado.IdEmpleado inner join cliente on turno.ClienteId = cliente.IdCliente WHERE FechaReserva = '$j' AND IdEmpleado = $h "
?>