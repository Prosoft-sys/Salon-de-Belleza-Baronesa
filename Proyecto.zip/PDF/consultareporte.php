<?php


$a = $_POST['docume'];

$consulta = "SELECT * FROM turno inner join servicio on turno.ServicioId = servicio.IdServicio inner join empleado on turno.EmpleadoId = empleado.IdEmpleado inner join cliente on turno.ClienteId = cliente.IdCliente WHERE IdCliente = $a ORDER BY IdTurno DESC";





?>