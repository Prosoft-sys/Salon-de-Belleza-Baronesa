<?php

$j = $_POST['fechahoy'];


$lp = "SELECT * FROM turno WHERE FechaReserva = '$j'";
?>