<?php



require ('../PDF/fpdf/fpdf.php');


class PDF extends FPDF
{
    function Header()
    {
        // Logo
    $this->Image('../PDF/logo.png',55,10,100);   
    $this->Ln(90);
    // Arial bold 15
    $this->SetFont('Arial','B',12);
    // Movernos a la derecha
    $this->Cell(55);
    // Título
    $this->Cell(90,10,'Reporte de turnos por cliente al dia',1,0,'C');
    // Salto de línea
    $this->Ln(20);

    $this->Cell(40,10,'Empleado:', 0, 0,'C',0);

    $this->Ln(20);

    $this->SetY(140);
    $this->SetX(10);
    $this->Cell(50,10,'Cliente', 1, 0,'C',0);  
   
    $this->SetY(140);
    $this->SetX(60);
    $this->Cell(50,10,'Servicio', 1, 0,'C',0);
    
    $this->SetY(140);
    $this->SetX(110);
    $this->Cell(60,10,'Hora', 1, 1,'C',0);
    
    //$this->Cell(40,10,'Fecha', 1, 1,'C',0);
   

    }

    function Footer()
    {
         // Posición: a 1,5 cm del final
    $this->SetY(-18);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Número de página
    $this->Cell(20,10,'Pagina '.$this->PageNo().'/{nb}',0,0,'C');


    }
}

require ('../BD/conectar.php');
require ('../PDF/consultareporte2.php');
$result = mysqli_query($db, $sql);

$pdf = new PDF('P','mm','Letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);



require ('../PDF/consultareporte3.php');
$resulto = mysqli_query($db, $ls);

$pdf = new PDF('P','mm','Letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);

require ('../PDF/consultareporte4.php');
$results = mysqli_query($db, $lp);

$pdf = new PDF('P','mm','Letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);


while($row = $result->fetch_assoc())
{
    
    $pdf->Cell(50,10,$row['NombreCliente'], 1, 0,'C',0);
    $pdf->Cell(50,10,$row['NombreServicio'], 1, 0,'C',0);  
    $pdf->Cell(60,10,$row['HoraReserva'], 1, 1,'C',0);     
    
}
while($riw = $resulto->fetch_assoc())
{
    $pdf->SetY(120);
    $pdf->SetX(30);
   $pdf->Cell(50,10,$riw['NombreEmpleado'], 0, 0,'C',0);
}

while($rew = $results->fetch_assoc())
{
    $pdf->SetY(120);
    $pdf->SetX(120);
   $pdf->Cell(50,10,$rew['FechaReserva'], 0, 0,'C',0);
}




$pdf->Output();


?>