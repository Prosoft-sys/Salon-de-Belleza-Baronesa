<?php

$a = $_POST['documentoempleado'];


$ls = "SELECT * FROM empleado WHERE IdEmpleado = $a"
?>