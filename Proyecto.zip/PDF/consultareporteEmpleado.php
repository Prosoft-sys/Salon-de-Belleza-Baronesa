<?php



require ('../PDF/fpdf/fpdf.php');


class PDF extends FPDF
{
    function Header()
    {
        // Logo
    $this->Image('../PDF/logo.png',55,10,100);   
    $this->Ln(90);
    // Arial bold 15
    $this->SetFont('Arial','B',12);
    // Movernos a la derecha
    $this->Cell(55);
    // Título
    $this->Cell(90,10,'Reportes Generalizados',1,0,'C');

    $this->Ln(20);

    $this->Cell(50,10,'Cliente', 0, 0,'C',0);

    $this->Ln(20);

    $this->SetY(140);
    $this->SetX(10);
    $this->Cell(50,10,'FechaReserva', 1, 0,'C',0);  
   
    $this->Ln(20);
    $this->SetY(140);
    $this->SetX(60);
    $this->Cell(50,10,'EmpleadoId', 1, 0,'C',0);
    $this->Ln(20);
    //$this->Cell(40,10,'Fecha', 1, 1,'C',0);
  

    }

    function Footer()
    {
         // Posición: a 1,5 cm del final
    $this->SetY(-18);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Número de página
    $this->Cell(20,10,'Pagina '.$this->PageNo().'/{nb}',0,0,'C');


    }
}

require ('../BD/conectar.php');
require ('../PDF/consultareporte15.php');
$result = mysqli_query($db, $sql);

$pdf = new PDF('P','mm','letter');
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Arial','',12);






while($row = $result->fetch_assoc())
{
    
    $pdf->Cell(50,10,$row['FechaReserva'], 1, 0,'C',0);
    $pdf->Cell(50,10,$row['EmpleadoId'], 1, 1,'C',0); 
    
   
    
}




$pdf->Output();


?>